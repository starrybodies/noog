# Noog portable kitty break 0.11.0

Serve this directory unchanged under any static path. Open kitty-game.html.
All scripts, styles, fonts and artwork use relative paths. No network calls,
analytics, storage, permissions, prizes or persistent rewards.

Mechanics: 15-second session, eight catches, explicit Start, Pause/Resume,
Play again and Close. Keyboard: Enter/Space on focused kitty; Escape closes.
Hidden pages pause; resuming requires visitor action. Reduced motion keeps
kitty stationary. Direct tabs dismiss to a closed screen; scripted popups close.

Website: reveal a labeled link after three keyboard/pointer mascot activations.
Reuse supplied kitty-lime.svg/kitty-sleepy.svg and optional kitty-mascot.css for
matching decoration. Hero uses reverse-sentinel-800.webp prominently beside copy.
Keep installation primary; never let this game change filters or demo state.

Copy game files unchanged from tested release kit; do not reconstruct game.
Source: https://github.com/starrybodies/noog/tree/ab710dc4028a33fd4e58104d61555a22f85f6162
Game/mascot changes commit ab710dc; esbuild 0.25.12 production IIFE, chrome116.
